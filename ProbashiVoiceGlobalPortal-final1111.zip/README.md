# Probashi Voice — Global Portal

Responsive public portal with eight country rooms, a Supabase-backed publishing system, and a protected admin console.

## Features
- Thailand, Malaysia, Saudi Arabia, UAE, Qatar, Oman, Kuwait and Bahrain room pages.
- Public published posts per room.
- Super Admin console at `/admin.html` for create, edit, draft, publish, archive, pin and delete.
- Approved Super Admin: `josismail869@gmail.com`.
- Supabase Row Level Security on room and post data.

## Run locally
```bash
npm start
```
Open `http://localhost:3000`.

See `SETUP.md` for auth, KYC and security guidance.
