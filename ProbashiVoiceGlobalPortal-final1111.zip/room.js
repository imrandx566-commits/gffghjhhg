const params = new URLSearchParams(location.search);
const slug = params.get('slug');
const title = document.querySelector('#room-title');
const tagline = document.querySelector('#room-tagline');
const code = document.querySelector('#room-code');
const status = document.querySelector('#room-status');
const list = document.querySelector('#post-list');

function esc(value='') { return value.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
function formatDate(value) { return new Intl.DateTimeFormat('en', { dateStyle:'medium' }).format(new Date(value)); }
async function loadRoom() {
  if (!slug) { title.textContent = 'Room not found'; status.textContent = 'Choose a country room from the homepage.'; return; }
  const { data: room, error: roomError } = await PV_SUPABASE.from('portal_regions').select('id,name,country_code,tagline').eq('project_slug','probashi-voice').eq('slug',slug).maybeSingle();
  if (roomError || !room) { title.textContent = 'Room not found'; status.textContent = 'This country room is not available.'; return; }
  title.textContent = room.name; tagline.textContent = room.tagline || 'Verified updates and tips for this country.'; code.textContent = `${room.country_code} · COUNTRY ROOM`;
  const { data: posts, error } = await PV_SUPABASE.from('portal_posts').select('id,title,body,post_type,is_pinned,published_at,created_at').eq('region_id',room.id).eq('status','published').order('is_pinned',{ascending:false}).order('published_at',{ascending:false}).limit(50);
  if (error) { status.textContent = 'Could not load posts right now.'; return; }
  status.textContent = posts.length ? `${posts.length} published update${posts.length === 1 ? '' : 's'}` : 'No published updates yet.';
  list.innerHTML = posts.map(post => `<article class="post-card"><div class="post-meta">${esc(post.post_type)} · ${formatDate(post.published_at || post.created_at)}${post.is_pinned ? ' · Pinned' : ''}</div><h2>${esc(post.title)}</h2><div class="post-body">${esc(post.body)}</div></article>`).join('');
}
loadRoom();
