# Probashi Voice — Admin & Room Setup

## Super Admin
The approved Super Admin allowlist is `josismail869@gmail.com`. Create or invite this email in Supabase Auth, enable email confirmation, and set a strong unique password. Then open `/admin.html` and sign in.

## Features
- Every country room has a public page at `/room.html?slug=<country-slug>`.
- Admin can create, edit, save drafts, publish, archive, pin, and delete posts.
- Public visitors can read published posts only.
- Supabase Row Level Security protects all room and post operations.
- The browser contains only the publishable key; service-role keys must never be added to frontend files.

## KYC and security guidance
Full KYC is not needed for ordinary content administration. Require identity verification only if the product later handles paid tips, payouts, regulated services, or another legal obligation. For current admin security: email confirmation, unique password, MFA/2FA, password recovery, least-privilege role allowlist, and audit history are recommended.

## Database
The migration `probashi_voice_room_posts_and_admin_security` was applied to the configured Supabase project. It created `portal_admins` and `portal_posts`, seeded all eight rooms, added policies, and enabled RLS on the existing portal tables.
