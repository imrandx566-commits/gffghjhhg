window.PV_SUPABASE_URL = 'https://pfyviyhdyjztqvvvibby.supabase.co';
window.PV_SUPABASE_KEY = 'sb_publishable_V8BlsMfB5VakOyFo8V2K5A_HpS4hVUU';
window.PV_SUPABASE = window.supabase.createClient(window.PV_SUPABASE_URL, window.PV_SUPABASE_KEY);
